# Compiler HEMATO-CELL depuis GitHub Actions

1. Créer un dépôt GitHub public ou privé nommé `HEMATO-CELL`.
2. Importer tous les fichiers et dossiers de ce projet (y compris le dossier caché `.github`).
3. Ouvrir l'onglet Actions du dépôt.
4. Choisir `Build HEMATO-CELL Android APK`, puis `Run workflow`.
5. Attendre la fin du travail. Si le build réussit, ouvrir le travail terminé et télécharger l'artefact `HEMATO-CELL-debug-apk`.
6. Décompresser l'artefact et installer `app-debug.apk` sur un appareil Android compatible.

Ce workflow produit un APK de débogage non signé pour distribution commerciale. Il sert uniquement aux essais.
