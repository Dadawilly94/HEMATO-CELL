package org.hematocell.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "exams")
data class ExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val caseCode: String,
    val specimen: String,
    val countsJson: String,
    val total: Int,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ExamDao {
    @Insert suspend fun insert(exam: ExamEntity)
    @Query("SELECT * FROM exams ORDER BY createdAt DESC") suspend fun all(): List<ExamEntity>
}
@Database(entities = [ExamEntity::class], version = 1, exportSchema = false)
abstract class HematoDatabase : RoomDatabase() {
    abstract fun examDao(): ExamDao
    companion object {
        @Volatile private var INSTANCE: HematoDatabase? = null
        fun get(context: Context): HematoDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, HematoDatabase::class.java, "hematocell.db").build().also { INSTANCE = it }
        }
    }
}

data class Cell(val id: String, val fr: String, val en: String, val morphFr: String, val morphEn: String)
val bloodCells = listOf(
    Cell("neu","Neutrophiles segmentés","Segmented neutrophils","Noyau généralement à 2–5 lobes, chromatine condensée ; cytoplasme rose pâle à granulations fines.","Usually 2–5 nuclear lobes, condensed chromatin; pale pink cytoplasm with fine specific granules."),
    Cell("band","Neutrophiles non segmentés","Band neutrophils","Noyau incurvé en bande ou fer à cheval, sans segmentation complète ; granulations neutrophiles.","Band- or horseshoe-shaped nucleus without complete segmentation; neutrophilic granules."),
    Cell("eos","Éosinophiles","Eosinophils","Noyau souvent bilobé ; grosses granulations orangées à rouge brique.","Usually bilobed nucleus; large orange-red granules."),
    Cell("bas","Basophiles","Basophils","Granulations grossières bleu-violet, parfois masquant le noyau.","Coarse blue-purple granules, sometimes obscuring the nucleus."),
    Cell("lym","Lymphocytes","Lymphocytes","Petite à moyenne cellule ; noyau rond, chromatine dense ; cytoplasme peu abondant.","Small to medium cell; round nucleus, dense chromatin; scant cytoplasm."),
    Cell("mon","Monocytes","Monocytes","Grande cellule ; noyau réniforme/plissé, chromatine fine ; cytoplasme gris-bleu parfois vacuolé.","Large cell; kidney-shaped/folded nucleus, fine chromatin; gray-blue sometimes vacuolated cytoplasm."),
    Cell("blast","Blastes","Blasts","Cellule immature : rapport nucléocytoplasmique souvent élevé, chromatine fine, nucléoles possibles. Décrire sans conclure sur la lignée.","Immature cell: often high N:C ratio, fine chromatin, possible nucleoli. Describe without assigning lineage."),
    Cell("ery","Érythroblastes","Nucleated red cells","Préciser le stade de maturation, la taille, la chromatine et la couleur du cytoplasme.","Record maturation stage, size, chromatin and cytoplasmic colour.")
)
val marrowCells = listOf(
    Cell("mb","Myéloblastes","Myeloblasts","Grande cellule, rapport N:C élevé, chromatine fine, nucléoles souvent visibles, cytoplasme basophile ; granulations parfois absentes.","Large cell, high N:C ratio, fine chromatin, often visible nucleoli, basophilic cytoplasm; granules may be absent."),
    Cell("pro","Promyélocytes","Promyelocytes","Cellule volumineuse, chromatine moins fine, nucléoles possibles ; granulations azurophiles primaires abondantes.","Large cell, less fine chromatin, possible nucleoli; abundant primary azurophilic granules."),
    Cell("my","Myélocytes neutrophiles","Neutrophilic myelocytes","Noyau rond/ovale excentré, chromatine plus condensée, nucléoles absents ; granulations spécifiques visibles.","Eccentric round/oval nucleus, more condensed chromatin, no nucleoli; specific granules visible."),
    Cell("meta","Métamyélocytes neutrophiles","Neutrophilic metamyelocytes","Noyau réniforme, chromatine condensée ; cytoplasme à granulations neutrophiles.","Kidney-shaped nucleus, condensed chromatin; neutrophilic granules."),
    Cell("band","PNN non segmentés","Band neutrophils","Noyau en bande ou fer à cheval, non segmenté ; chromatine condensée.","Band/horseshoe nucleus, not segmented; condensed chromatin."),
    Cell("neu","PNN segmentés","Segmented neutrophils","Noyau plurilobé, chromatine condensée ; granulations neutrophiles fines.","Multilobed nucleus, condensed chromatin; fine neutrophilic granules."),
    Cell("eos","Éosinophiles","Eosinophils","Noyau souvent bilobé ; granulations orangées abondantes.","Usually bilobed nucleus; abundant orange granules."),
    Cell("bas","Basophiles","Basophils","Granulations métachromatiques bleu-violet grossières.","Coarse metachromatic blue-purple granules."),
    Cell("proe","Proérythroblastes","Proerythroblasts","Grande cellule, noyau rond, chromatine fine, nucléoles possibles ; cytoplasme intensément basophile.","Large cell, round nucleus, fine chromatin, possible nucleoli; intensely basophilic cytoplasm."),
    Cell("eb","Érythroblastes basophiles","Basophilic erythroblasts","Noyau rond central, chromatine en condensation ; cytoplasme très basophile.","Central round nucleus, condensing chromatin; deeply basophilic cytoplasm."),
    Cell("ep","Érythroblastes polychromatophiles","Polychromatic erythroblasts","Chromatine en mottes ; cytoplasme gris-bleu par hémoglobinisation progressive.","Clumped chromatin; gray-blue cytoplasm due to progressive haemoglobinization."),
    Cell("ea","Érythroblastes acidophiles","Orthochromatic erythroblasts","Noyau pycnotique ; cytoplasme rose-orangé riche en hémoglobine.","Pyknotic nucleus; pink-orange haemoglobin-rich cytoplasm."),
    Cell("lym","Lymphocytes","Lymphocytes","Noyau rond, chromatine dense ; cytoplasme peu abondant dans les formes matures.","Round nucleus, dense chromatin; scant cytoplasm in mature forms."),
    Cell("mon","Monocytes","Monocytes","Noyau réniforme ou plissé, chromatine fine ; cytoplasme gris-bleu.","Kidney-shaped/folded nucleus, fine chromatin; gray-blue cytoplasm."),
    Cell("pla","Plasmocytes","Plasma cells","Noyau excentré, chromatine en rayon de roue, cytoplasme basophile et halo périnucléaire possible.","Eccentric nucleus, clock-face chromatin, basophilic cytoplasm and possible perinuclear hof."),
    Cell("meg","Mégacaryocytes","Megakaryocytes","Très grande cellule, noyau multilobé/polyploïde, cytoplasme abondant ; évaluer sur particules médullaires.","Very large cell, multilobulated/polyploid nucleus, abundant cytoplasm; assess on marrow particles."),
    Cell("mast","Mastocytes","Mast cells","Cellule ronde/ovale, granulations métachromatiques violettes pouvant masquer le noyau.","Round/oval cell, purple metachromatic granules may obscure the nucleus.")
)
val disorders = listOf(
    Triple("LAM / AML","WHO-HAEM5 : distinguer les LAM avec anomalies génétiques définissantes et les LAM définies par la différenciation. Décrire blastes, granulations et bâtonnets d’Auer ; la morphologie seule ne suffit pas.","WHO-HAEM5: distinguish AML with defining genetic abnormalities from AML defined by differentiation. Describe blasts, granules and Auer rods; morphology alone is insufficient.","Cytométrie en flux, caryotype/FISH et analyses moléculaires ciblées ; appliquer les critères WHO-HAEM5 à l’entité suspectée."),
    Triple("LAL / ALL","Décrire taille, rapport nucléocytoplasmique, chromatine, nucléoles et cytoplasme. L'assignation B ou T n'est pas fiable sur la seule morphologie.","Describe size, N:C ratio, chromatin, nucleoli and cytoplasm. B- or T-lineage cannot be assigned reliably by morphology alone.","Immunophénotypage multiparamétrique, cytogénétique et biologie moléculaire."),
    Triple("LMC / CML","Granulocytose avec spectre de maturation myéloïde et basophilie possible. Une morphologie évocatrice doit conduire à la recherche de BCR::ABL1.","Granulocytosis with myeloid maturation spectrum and possible basophilia. Suggestive morphology requires BCR::ABL1 testing.","BCR::ABL1 par PCR et/ou FISH ; corrélation clinique, hémogramme et moelle."),
    Triple("LLC / CLL","Petits lymphocytes matures à chromatine condensée ; ombres de Gumprecht possibles, non spécifiques.","Mature small lymphocytes with condensed chromatin; smudge cells may occur and are not specific.","Immunophénotypage sanguin et critères cliniques/biologiques."),
    Triple("SMD / MDS","Dysplasie d’une ou plusieurs lignées : anomalies nucléaires/cytoplasmiques ; quantifier les blastes.","Dysplasia in one or more lineages: nuclear/cytoplasmic abnormalities; quantify blasts.","Exclure causes secondaires ; cytogénétique, biologie moléculaire et classification actuelle."),
    Triple("Néoplasies myéloprolifératives / MPN","Prolifération d’une ou plusieurs lignées ; mégacaryocytes anormaux selon l’entité.","Proliferation of one or more lineages; abnormal megakaryocytes depending on entity.","JAK2, CALR, MPL, BCR::ABL1 selon contexte et critères de classification.")
)
data class Triple(val name:String,val fr:String,val en:String,val tests:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = HematoDatabase.get(this)
        setContent { HematoApp(db) }
    }
}
@Composable
fun HematoApp(db: HematoDatabase) {
    var english by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<ExamEntity>>(emptyList()) }
    LaunchedEffect(Unit) { saved = db.examDao().all() }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF126B68), secondary = androidx.compose.ui.graphics.Color(0xFF547C91))) {
        Scaffold(
            topBar = {
                TopAppBarCompat(
                    title = "HEMATO-CELL",
                    subtitle = if (english) "Haematology cytology assistant" else "Assistant de cytologie hématologique",
                    english = english,
                    onLanguage = { english = !english }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf(if(english)"Count" else "Comptage", if(english)"Atlas" else "Atlas", if(english)"Disorders" else "Hémopathies", if(english)"Saved" else "Examens").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab==i, onClick={tab=i}, icon={Text(listOf("＋","◉","✚","▤")[i])}, label={Text(label)})
                    }
                }
            }
        ) { padding ->
            when(tab) {
                0 -> CounterScreen(english, db, onSaved = { saved = db.examDao().all() }, Modifier.padding(padding))
                1 -> AtlasScreen(english, Modifier.padding(padding))
                2 -> DisordersScreen(english, Modifier.padding(padding))
                else -> SavedScreen(english, saved, onExportPdf = { exportPdf(ctx, saved, english) }, onExportXlsx = { exportXlsx(ctx, saved) }, Modifier.padding(padding))
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title:String, subtitle:String, english:Boolean, onLanguage:()->Unit) {
    TopAppBar(title={Column { Text(title, fontWeight=FontWeight.Bold); Text(subtitle, style=MaterialTheme.typography.labelSmall) }},
        actions={ TextButton(onClick=onLanguage){Text(if(english)"FR" else "EN")} })
}
@Composable
fun CounterScreen(en:Boolean, db:HematoDatabase, onSaved:()->Unit, modifier:Modifier=Modifier) {
    var marrow by remember { mutableStateOf(false) }
    var target by remember { mutableIntStateOf(100) }
    var selected by remember { mutableStateOf("neu") }
    val cells = if(marrow) marrowCells else bloodCells
    val counts = remember(marrow) { mutableStateMapOf<String,Int>().apply { cells.forEach { put(it.id,0) } } }
    var caseCode by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val total = cells.sumOf { counts[it.id] ?: 0 }
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(if(en)"Manual differential count" else "Comptage différentiel manuel", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        OutlinedTextField(caseCode,{caseCode=it},label={Text(if(en)"Pseudonymized case ID" else "Identifiant pseudonymisé")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically) {
            FilterChip(selected=!marrow,onClick={marrow=false;selected="neu"},label={Text(if(en)"Peripheral blood" else "Sang périphérique")})
            Spacer(Modifier.width(8.dp))
            FilterChip(selected=marrow,onClick={marrow=true;selected="mb"},label={Text(if(en)"Bone marrow" else "Moelle")})
        }
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text(if(en)"Target" else "Objectif",fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.width(12.dp))
            listOf(100,200,500).forEach { n -> FilterChip(selected=target==n,onClick={target=n},label={Text("$n")}) }
        }
        LinearProgressIndicator(progress={ (total.toFloat()/target).coerceIn(0f,1f) }, modifier=Modifier.fillMaxWidth())
        Text("$total / $target  •  ${if(target>0)(100f*total/target).let{"%.1f".format(Locale.US,it)} else "0"} %")
        if (marrow) {
            val granulocytic = listOf("mb","pro","my","meta","band","neu","eos","bas").sumOf { counts[it] ?: 0 }
            val erythroid = listOf("proe","eb","ep","ea").sumOf { counts[it] ?: 0 }
            val ge = if (erythroid > 0) "%.2f".format(Locale.US, granulocytic.toFloat()/erythroid) else "—"
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Text(if(en)"Granulocytic / erythroid ratio (G:E)" else "Rapport granulocytaire / érythroblastique (G:E)", fontWeight=FontWeight.SemiBold)
                    Text(ge, style=MaterialTheme.typography.headlineSmall)
                    Text(if(en)"Calculated from the categories counted in this session; review category completeness and local method before interpretation." else "Calculé à partir des catégories comptées dans cette session ; vérifier l'exhaustivité et la méthode locale avant interprétation.", style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        val current = cells.firstOrNull { it.id==selected } ?: cells.first()
        ElevatedCard {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(if(en)current.en else current.fr, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
                Text("${counts[selected] ?: 0}  •  ${if(total>0)"%.1f".format(Locale.US,100f*(counts[selected]?:0)/total) else "0.0"} %",style=MaterialTheme.typography.headlineMedium)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    OutlinedButton(onClick={counts[selected]=((counts[selected]?:0)-1).coerceAtLeast(0)},enabled=(counts[selected]?:0)>0){Icon(Icons.Default.Remove,null)}
                    Spacer(Modifier.width(12.dp))
                    Button(onClick={counts[selected]=(counts[selected]?:0)+1},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text(if(en)" Count cell" else " Compter la cellule")}
                }
            }
        }
        Text(if(en)"Select observed cell" else "Sélectionner la cellule observée",fontWeight=FontWeight.SemiBold)
        cells.forEach { c ->
            Card(onClick={selected=c.id}, colors=CardDefaults.cardColors(containerColor=if(selected==c.id)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(if(en)c.en else c.fr,Modifier.weight(1f))
                    Text("${counts[c.id]?:0}",fontWeight=FontWeight.Bold)
                    TextButton(onClick={selected=c.id}){Text(if(en)"Select" else "Choisir")}
                }
            }
        }
        OutlinedTextField(notes,{notes=it},label={Text(if(en)"Morphological comments" else "Observations morphologiques")},modifier=Modifier.fillMaxWidth(),minLines=2)
        Button(onClick={
            val json = cells.joinToString(prefix="{",postfix="}") { "\"${it.id}\":${counts[it.id]?:0}" }
            scope.launch {
                db.examDao().insert(ExamEntity(caseCode=caseCode.ifBlank{"NON_RENSEIGNE"},specimen=if(marrow)"MARROW" else "BLOOD",countsJson=json,total=total,notes=notes))
                onSaved(); message=if(en)"Exam saved on this device" else "Examen enregistré sur cet appareil"
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(en)"Save examination" else "Enregistrer l'examen")}
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary)
        if(total>target) Text(if(en)"Warning: count exceeds the selected target." else "Attention : le comptage dépasse l'objectif sélectionné.",color=MaterialTheme.colorScheme.error)
        Text(if(en)"Percentages are calculated from the cells counted so far. The target is a workflow target, not a diagnostic threshold." else "Les pourcentages sont calculés sur les cellules déjà comptées. L'objectif est un repère de travail, pas un seuil diagnostique.",style=MaterialTheme.typography.bodySmall)
    }
}
@Composable
fun AtlasScreen(en:Boolean, modifier:Modifier=Modifier) {
    var marrow by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val cells=if(marrow)marrowCells else bloodCells
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(if(en)"Morphology atlas" else "Atlas morphologique",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        OutlinedTextField(query,{query=it},label={Text(if(en)"Search a cell" else "Rechercher une cellule")},modifier=Modifier.fillMaxWidth())
        Row { FilterChip(selected=!marrow,onClick={marrow=false},label={Text(if(en)"Blood" else "Sang")});Spacer(Modifier.width(8.dp));FilterChip(selected=marrow,onClick={marrow=true},label={Text(if(en)"Marrow" else "Moelle")}) }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(cells.filter{(if(en)it.en else it.fr).contains(query,true)}) { c ->
                ElevatedCard { Column(Modifier.padding(12.dp)) {
                    Text(if(en)c.en else c.fr,fontWeight=FontWeight.Bold)
                    Text(if(en)c.morphEn else c.morphFr)
                    Text(if(en)"Describe size, nucleus, chromatin, nucleoli and cytoplasm systematically." else "Décrire systématiquement la taille, le noyau, la chromatine, les nucléoles et le cytoplasme.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.secondary)
                } }
            }
        }
    }
}
@Composable
fun DisordersScreen(en:Boolean, modifier:Modifier=Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(if(en)"Haematological malignancies — orientation" else "Hémopathies malignes — orientation",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text(if(en)"Educational decision support only. Morphology alone cannot establish a definitive diagnosis." else "Aide pédagogique à l'orientation uniquement. La morphologie seule ne permet pas d'établir un diagnostic définitif.",color=MaterialTheme.colorScheme.error)
        disorders.forEach { d -> ElevatedCard { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(d.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)
            Text(if(en)d.en else d.fr)
            Text((if(en)"Additional tests: " else "Examens complémentaires : ")+d.tests,style=MaterialTheme.typography.bodySmall)
        } } }
        Text(if(en)"Use current WHO/ICC classifications and local validated protocols." else "Utiliser les classifications OMS/ICC en vigueur et les protocoles locaux validés.",style=MaterialTheme.typography.bodySmall)
    }
}
@Composable
fun SavedScreen(en:Boolean, exams:List<ExamEntity>, onExportPdf:()->Unit, onExportXlsx:()->Unit, modifier:Modifier=Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(if(en)"Saved examinations" else "Examens enregistrés",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(onClick=onExportPdf,enabled=exams.isNotEmpty(),modifier=Modifier.weight(1f)){Text("PDF")}
            Button(onClick=onExportXlsx,enabled=exams.isNotEmpty(),modifier=Modifier.weight(1f)){Text("Excel")}
        }
        if(exams.isEmpty()) Text(if(en)"No saved examination yet." else "Aucun examen enregistré.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(exams) { e -> ElevatedCard { Column(Modifier.padding(12.dp)) {
                Text(e.caseCode,fontWeight=FontWeight.Bold)
                Text("${e.specimen} • ${e.total} cells")
                Text(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date(e.createdAt)),style=MaterialTheme.typography.labelSmall)
                Text(e.countsJson,style=MaterialTheme.typography.bodySmall)
                if(e.notes.isNotBlank())Text(e.notes)
            } } }
        }
    }
}

fun shareExport(context: Context, file: File, mime: String, chooser: String) {
    val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, chooser))
}

fun exportPdf(context: Context, exams: List<ExamEntity>, en: Boolean) {
    val pdf = PdfDocument()
    val paint = Paint().apply { textSize = 11f }
    val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
    var pageNo = 1
    var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
    var y = 48f
    fun line(text: String, bold: Boolean = false) {
        if (y > 790f) {
            pdf.finishPage(page); pageNo++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); y = 48f
        }
        page.canvas.drawText(text.take(95), 40f, y, if (bold) titlePaint else paint)
        y += if (bold) 28f else 18f
    }
    line("HEMATO-CELL — ${if(en) "Examination report" else "Compte rendu d'examen"}", true)
    line(if(en) "Educational counting report — not a diagnostic conclusion" else "Rapport de comptage pédagogique — ne constitue pas une conclusion diagnostique")
    line(" ")
    exams.forEach { e ->
        line("${e.caseCode} | ${e.specimen} | ${e.total} ${if(en)"cells" else "cellules"}", true)
        line(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date(e.createdAt)))
        line("Counts: ${e.countsJson}")
        if(e.notes.isNotBlank()) line("Notes: ${e.notes}")
        line(" ")
    }
    pdf.finishPage(page)
    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, "HEMATO_CELL_report_${System.currentTimeMillis()}.pdf")
    FileOutputStream(file).use { pdf.writeTo(it) }
    pdf.close()
    shareExport(context, file, "application/pdf", if(en)"Share PDF report" else "Partager le rapport PDF")
}

/** Minimal Office Open XML workbook with one worksheet, readable by Excel and LibreOffice. */
fun exportXlsx(context: Context, exams: List<ExamEntity>) {
    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, "HEMATO_CELL_exams_${System.currentTimeMillis()}.xlsx")
    val rows = mutableListOf(listOf("Case ID","Specimen","Total cells","Counts JSON","Morphology notes","Created (epoch ms)"))
    exams.forEach { rows.add(listOf(it.caseCode,it.specimen,it.total.toString(),it.countsJson,it.notes,it.createdAt.toString())) }
    fun col(n0:Int):String {
        var n=n0+1; var out=""
        while(n>0){ val r=(n-1)%26; out=('A'.code+r).toChar()+out; n=(n-1)/26 }
        return out
    }
    fun esc(v:String)=v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    ZipOutputStream(FileOutputStream(file)).use { zip ->
        fun entry(name:String, content:String) {
            zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
        }
        entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
        entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Examinations" sheetId="1" r:id="rId1"/></sheets></workbook>""")
        entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
        val sheet = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            rows.forEachIndexed { ri,row ->
                append("<row r=\"${ri+1}\">")
                row.forEachIndexed { ci,value ->
                    append("<c r=\"${col(ci)}${ri+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>")
                }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }
        entry("xl/worksheets/sheet1.xml", sheet)
    }
    shareExport(context,file,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Partager le fichier Excel")
}
